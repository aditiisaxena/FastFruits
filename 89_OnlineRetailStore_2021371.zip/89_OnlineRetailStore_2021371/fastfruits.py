import pandas as pd
import mysql.connector
import tkinter as tk
from tkinter import ttk

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="uwu123",
    database="FastFruits"
)

mycursor = mydb.cursor()

def display_table(data):
    window = tk.Tk()
    window.title("Table View")
    table = ttk.Treeview(window, show="headings", columns=tuple(data.columns))
    for column in data.columns:
        table.heading(column, text=column)
    for row in data.to_numpy():
        table.insert("", "end", values=tuple(row))
    scrollbar = ttk.Scrollbar(window, orient="vertical", command=table.yview)
    scrollbar.pack(side="right", fill="y")
    table.configure(yscrollcommand=scrollbar.set)
    table.pack(side="left", fill="both", expand=True)
    window.mainloop()

def login():
    email = input("Enter your email: ")
    password = input("Enter your password: ")
    mycursor.execute("SELECT * FROM Customers WHERE email = %s", (email,))
    result = mycursor.fetchall()
    while len(result) == 0:
        print("Invalid email")
        email = input("Enter your email: ")
        mycursor.execute("SELECT * FROM Customers WHERE email = %s", (email,))
        result = mycursor.fetchall()
    return result

def signup():
    first_name = input("Enter your first name: ")
    last_name = input("Enter your last name: ")
    age = input("Enter your age: ")
    gender = input("Male/Female/Other: ")
    email = input("Enter your email: ")
    phone = input("Enter your phone number: ")
    street = input("Enter your street: ")
    city = input("Enter your city: ")
    states = input("Enter your state: ")
    pincode = input("Enter your pincode: ")
    mycursor.execute("INSERT INTO `Customers` VALUES (101,  %s,  'unde',  %s,  %s,  %s,  %s, %s,  %s,  %s,  %s,  %s,  1)", (first_name, last_name, age, gender, email, phone, street, city, states, pincode))
    mydb.commit()

menu = """
1. Enter as customer 🛍️
2. Enter as admin 🧑‍💻
3. Exit 🚪
"""

customer = """
1. Login 🏪
2. Create account 📝
3. Back 🚪
"""

feature = """
1. Products 🥭
2. Add to Cart 🛒
3. Checkout 🛍️
4. Back 🚪
"""

admin = """
1. Add fruit 🍎
2. Add salad 🥗
3. Add smoothie 🥤
4. Check products close to expiration 📅
5. Check products that are out of stock 🚫
6. Back 🚪
"""

print("🍎Welcome to FastFruits🥭")
while True:
    print(menu)
    choice = input("Enter your choice: ")
    if choice == "1":
        while True:
            print(customer)
            choice = input("Enter your choice: ")
            if choice == "1":
                result = login()
                print("Welcome, " + result[0][1] + "!")
                while True:
                    print(feature)
                    choice = input("Enter your choice: ")
                    if choice == "1":
                        mycursor.execute("SELECT * FROM `Fruits`")
                        data = pd.DataFrame(mycursor.fetchall(), columns=mycursor.column_names)
                        display_table(data)
                        mycursor.execute("SELECT * FROM `Salad`")
                        data = pd.DataFrame(mycursor.fetchall(), columns=mycursor.column_names)
                        display_table(data)
                        mycursor.execute("SELECT * FROM `Smoothies`")
                        data = pd.DataFrame(mycursor.fetchall(), columns=mycursor.column_names)
                        display_table(data)
                    elif choice == "2":
                        name = input("Enter the name of the product: ")
                        quantity = input("Enter the quantity of the product: ")
                        mycursor.execute("SELECT * FROM `Fruits` WHERE name = %s", (name,))
                        if len(mycursor.fetchall()) != 0:
                            type = "Fruit"
                            mycursor.execute("INSERT INTO `myCart` VALUES (%s,  %s,  %s, %s)", (name, type, 251, quantity))
                            mydb.commit()
                            print("Added to cart successfully!")
                        mycursor.execute("SELECT * FROM `Salad` WHERE name = %s", (name,))
                        if len(mycursor.fetchall()) != 0:
                            type = "Salad"
                            mycursor.execute("INSERT INTO `myCart` VALUES (%s,  %s,  %s, %s)", (name, type, 431, quantity))
                            mydb.commit()
                            print("Added to cart successfully!")
                        mycursor.execute("SELECT * FROM `Smoothies` WHERE name = %s", (name,))
                        if len(mycursor.fetchall()) != 0:
                            type = "Smoothie"
                            mycursor.execute("INSERT INTO `myCart` VALUES (%s,  %s,  %s, %s)", (name, type, 258, quantity))
                            mydb.commit()
                            print("Added to cart successfully!")
                    elif choice == "3":
                        mycursor.execute("SELECT * FROM `myCart`")
                        data = pd.DataFrame(mycursor.fetchall(), columns=mycursor.column_names)
                        display_table(data)
                        mycursor.execute("SELECT * FROM `myCart`")
                        result = mycursor.fetchall()
                        total = 0
                        for i in result:
                            total += int(i[3]) * int(i[2])
                        print("Total: " + str(total))
                        mycursor.execute("DELETE FROM `myCart`")
                        mydb.commit()
                        print("Thank you for shopping with us!")
                    elif choice == "4":
                        break
                    else:
                        print("Invalid choice")
            elif choice == "2":
                signup()
                print("Account created successfully!")
            elif choice == "3":
                break
            else:
                print("Invalid choice")
    elif choice == "2":
        username = input("Enter your username: ")
        password = input("Enter your password: ")
        while username != "uwuditi" or password != "uwu123":
            print("Invalid username or password")
            username = input("Enter your username: ")
            password = input("Enter your password: ")
        print("Welcome Admin!")
        while True:
            print(admin)
            choice = input("Enter your choice: ")
            if choice == "1":
                name = input("Enter the name of the fruit: ")
                price = input("Enter the price of the fruit: ")
                quantity = input("Enter the quantity of the fruit: ")
                mycursor.execute("INSERT INTO `Fruits` VALUES (101,  %s,  %s,  %s,  '2021-12-31',  '2022-12-31')", (name, price, quantity))
                mydb.commit()
                print("Fruit added successfully!")
            elif choice == "2":
                name = input("Enter the name of the salad: ")
                price = input("Enter the price of the salad: ")
                quantity = input("Enter the quantity of the salad: ")
                mycursor.execute("INSERT INTO `Salad` VALUES (101,  %s,  %s,  %s,  '2021-12-31',  '2022-12-31')", (name, price, quantity))
                mydb.commit()
                print("Salad added successfully!")
            elif choice == "3":
                name = input("Enter the name of the smoothie: ")
                price = input("Enter the price of the smoothie: ")
                quantity = input("Enter the quantity of the smoothie: ")
                mycursor.execute("INSERT INTO `Smoothies` VALUES (101,  %s, %s,  %s,  '2021-12-31',  '2022-12-31')", (name, price, quantity))
                mydb.commit()
                print("Smoothie added successfully!")
            elif choice == "4":
                mycursor.execute("SELECT * FROM `Fruits` ORDER BY expiryDate ASC")
                data = pd.DataFrame(mycursor.fetchall(), columns=mycursor.column_names)
                display_table(data)
                mycursor.execute("SELECT * FROM `Salad` ORDER BY expiryDate ASC")
                data = pd.DataFrame(mycursor.fetchall(), columns=mycursor.column_names)
                display_table(data)
                mycursor.execute("SELECT * FROM `Smoothies` ORDER BY expiryDate ASC")
                data = pd.DataFrame(mycursor.fetchall(), columns=mycursor.column_names)
                display_table(data)
            elif choice == "5":
                mycursor.execute("SELECT * FROM `Fruits` WHERE quantity = 0")
                data = pd.DataFrame(mycursor.fetchall(), columns=mycursor.column_names)
                display_table(data)
                mycursor.execute("SELECT * FROM `Salad` WHERE quantity = 0")
                data = pd.DataFrame(mycursor.fetchall(), columns=mycursor.column_names)
                display_table(data)
                mycursor.execute("SELECT * FROM `Smoothies` WHERE quantity = 0")
                data = pd.DataFrame(mycursor.fetchall(), columns=mycursor.column_names)
                display_table(data)
            elif choice == "6":
                break
    elif choice == "3":
        print("Thank you for using our application!")
        quit()

